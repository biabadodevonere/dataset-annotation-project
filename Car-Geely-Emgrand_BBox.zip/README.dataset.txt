# Geely - Emgrand 2 > SetA_BBox
https://universe.roboflow.com/fine-grained-annotation-jqrx9/geely-emgrand-2-n6qvw

Provided by a Roboflow user
License: CC BY 4.0

