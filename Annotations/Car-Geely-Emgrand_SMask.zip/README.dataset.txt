# Geely - Emgrand SMASK > SetA_SMask
https://universe.roboflow.com/fine-grained-annotation-jqrx9/geely-emgrand-smask-h9r0u

Provided by a Roboflow user
License: CC BY 4.0

